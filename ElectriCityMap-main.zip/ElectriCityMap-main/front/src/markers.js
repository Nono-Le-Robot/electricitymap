export const userPositionIcon = "../assets/myPosition.png";
