<!-- update log :  -->
<!-- v1.0 : création des bases de l'app (ajout de points, compte, bdd etc..) -->
<!-- v1.1 : fix bug contour blanc sur android -->
<!-- v1.2 : ajout du control de version -->
