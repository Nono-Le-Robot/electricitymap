const apiUrl = "https://electricitymap.fr/backend";
// const apiUrl = "http://localhost:5000/backend";
const minRadiusToAddPoint = 3;
